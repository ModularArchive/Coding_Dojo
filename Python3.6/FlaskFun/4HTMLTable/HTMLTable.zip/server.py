from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = "asdasdasd"


@app.route('/')
def HTML_Table():
    users = (
    {'first_name' : 'Michael', 'last_name' : 'Choi'},
    {'first_name' : 'John', 'last_name' : 'Supsupin'},
    {'first_name' : 'Mark', 'last_name' : 'Guillen'},
    {'first_name' : 'KB', 'last_name' : 'Tonel'}
    )
    return render_template('index.html', users=users)


app.run(debug="TRUE")