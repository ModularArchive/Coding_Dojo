Assignment: Dojo Survey With Validation
Objectives:
Practice validating user input
Practice using flash messages



Take the Dojo Survey assignment that you completed previously and add validations! The Name and Comment fields should be validated so that they are not blank. Also, validate that the comment field is no longer than 120 characters.

