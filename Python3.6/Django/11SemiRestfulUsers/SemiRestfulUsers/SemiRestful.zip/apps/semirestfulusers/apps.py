from django.apps import AppConfig


class SemirestfulusersConfig(AppConfig):
    name = 'semirestfulusers'
