from django.apps import AppConfig


class SessionwordsConfig(AppConfig):
    name = 'sessionwords'
