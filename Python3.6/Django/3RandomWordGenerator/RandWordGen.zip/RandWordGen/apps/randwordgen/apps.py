from django.apps import AppConfig


class RandwordgenConfig(AppConfig):
    name = 'randwordgen'
